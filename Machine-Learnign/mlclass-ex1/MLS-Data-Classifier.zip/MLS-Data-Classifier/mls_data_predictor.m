%% Code for predicting Model
%
%  Author: Harshit Bangar
%  ------------
% 
%  This file contains code for building Simple Models for data
%  
%  1) Linear Regression (Gradient descent - chosen for simplicity and checked with fast 
%     convergence in 300 iterations.)
%
%  2) Linear Regression - Normal Equation (works fine since the number
%     of dimensions are not high. Much fast compared to linear regression)
%
%  3) Advanced optimization techniques(Conjugate Gradient- used octave's inbuilt method)
%
%  The evaluation is done by plotting Cost function.
%
%  The results shows that linear modeling is not sufficient and need to be modeled
%  with higher order terms or Neural Networks. Also the data don't have overfitting issues
% 
%  To see impact on new data 70% of data can be used as training 
%  and remaining 30% as test example. 
%  (minor extension)
%
%  Note: The code is an extension of my Coursera ML-Class work

%% Initialization
clear ; close all; clc

%%==============Reading the Data========%%
fprintf('Reading Input ... \n');
data = load('mls_data.txt');
[nrows, ncols] = size(data);
X = data(:, 2:ncols); 
y = data(:, 1);

[X mu sigma] = featureNormalize(X); %Normalizing the feature for faster convergence

X = [ones(nrows, 1) X]; %Adding the bias

fprintf('Program paused. Press enter to see Gradient descent.\n');
pause;
%%===========Linear Regression=========%%

%% Gradient descent
alpha = 0.1;
num_iters = 400;
thetaGD = zeros(ncols, 1);
[thetaGD, J_history] = gradientDescentMulti(X, y, thetaGD, alpha, num_iters);
figure;
plot(1:numel(J_history), J_history, '-b', 'LineWidth', 2);
xlabel('Number of iterations');
ylabel('Cost J');

fprintf('Program paused. Press enter to see Normal Equation.\n');
pause;

%% Normal Equation
fprintf('Normal Equation Output ... \n');
thetaNE = zeros(ncols, 1);
thetaNE = normalEqn(X, y);
disp(1/(2*nrows)*sum((X*thetaNE-y).^2));

fprintf('Program paused. Press enter to see Conjugate Gradient.\n');
pause;

%%==========Conjugate Gradient(slow-need optimization in cost function 
%%                                  since it is making matrix calculation in each iteration)=======%%

options =optimset('GradObj', 'on', 'MaxIter', '100'); 
initialTheta = zeros(ncols, 1);
[optTheta,functionVal,exitFlag]=fminunc(@costFunction,initialTheta, options); 
fprintf('Conjugate Gradient Output ... \n');
disp(1/(2*nrows)*sum((X*optTheta-y).^2));
